<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script type="text/javascript" src="jquery-3.3.1.min.js">
    </script>
</head>

<body>
    <div id="loader"></div>
    <center>
        <section class="contact-us">
            <div class="contactus-head"><b>Please fill in following form to contact us</b></div>
            <div class="contactus-body">
                <form id="frm_contact" name="frm_contact" action="" method="post">
                    <table style="width:90%;">
                        <tr>
                            <td><span style="color:red;">*</span> Your Name</td>
                            <td><input type="text" id="name" name="name" title="Enter Only Character" required></td>
                        </tr>
                        <tr>
                            <td><span style="color:red;">*</span>Email</td>
                            <td><input type="text" id="email" name="email" required></td>
                        </tr>
                        <tr>
                            <td><span style="color:red;">*</span>Phone</td>
                            <td><input type="text" id="phone" title="Enter 10 digit Phone number" name="phone" required></td>
                        </tr>
                        <tr>
                            <td>Subject</td>
                            <td><select id="subject" name="subject">
                                    <option value="General">General</option>
                                    <option value="Sales Department">Sales Department</option>
                                    <option value="Report an Issue">Report an Issue</option>
                                </select></td>
                        </tr>
                        <tr>
                            <td><span style="color:red;">*</span>your Comments</td>
                            <td><textarea id="comment" name="comment" cols="30" rows="5" required></textarea></td>
                        </tr>
                        <tr>
                            <td><span style="color:red;">*</span>Are You human?<br/>
                                    <?php
                                    $a=rand(0,20);
                                    $b=rand(0,20);
                                    echo "$a + $b = ";
                                ?>
                                    <input type="hidden" id="a_val" value="<?php echo $a; ?>" />
                                    <input type="hidden" id="b_val" value="<?php echo $b; ?>" />
                            </td>
                            <td><input style="width:40px;" type="text" id="human_ans" required></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <div id="err_list" style="color:red;" </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <br/><button type="submit" class="frm-submit" id="submit" name="submit">Submit</button>
                            </td>
                            <td></td>
                        </tr>
                    </table>
                </form>
            </div>
        </section>
    </center>
</body>
<script type="text/javascript" src="main.js">
</script>

</html>