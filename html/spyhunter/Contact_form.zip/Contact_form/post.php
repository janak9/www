<?php
    // Import PHPMailer classes into the global namespace
    // These must be at the top of your script, not inside a function
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    //Load Composer's autoloader
    
    require 'vendor/autoload.php';
    require 'vendor/phpmailer/phpmailer/src/Exception.php';
    require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
    require 'vendor/phpmailer/phpmailer/src/SMTP.php';
    $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
    try {
        require_once 'vendor/phpmailer/phpmailer/src/ServerSettings.php';
        //Recipients
        $mail->addAddress($sender_email, 'receiver Name');     // Add a recipient
    
        //Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Contact Us';
        $mail->Body    = "<b>".$_REQUEST['name']."</b> want to contact you.<br><br>
        Details are as follow:
        <br>Name : ".$_REQUEST['name']."
        <br>Email : ".$_REQUEST['email']."
        <br>Phone Number : ".$_REQUEST['phone']."
        <br>Subject : ".$_REQUEST['subject']."
        <br>Comment : ".$_REQUEST['comment'];
    
        $mail->send();  
        return true;
    } catch (Exception $e) {
        echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
        return false;
    }
?>