$(document).ready(function() {
	$('form').on('submit', function(e) {
		e.preventDefault();
		var name = document.getElementById("name").value;
		var email = document.getElementById("email").value;
		var phno = document.getElementById("phone").value;
		var subject = document.getElementById("subject").value;
		var comment = document.getElementById("comment").value;
		var a = parseInt(document.getElementById("a_val").value);
		var b = parseInt(document.getElementById("b_val").value);
		var human_ans = parseInt(document.getElementById("human_ans").value);
		var nameRGEX = /^[a-zA-Z ]+$/;
		var phnoRGEX = /^[0-9]{10}$/;
		var emailRGEX = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z]{2,4}$/;
		var nameRes = name.match(nameRGEX);
		var phoneRes = phno.match(phnoRGEX);
		var emailRes = email.match(emailRGEX);
		var err_text = "";
		if (name.length==0 || !nameRes){
			err_text = err_text + "<br>Please Enter Valid Name.";
		}
		if (email.length==0 || !emailRes) {
			err_text = err_text + "<br>Please Enter Valid Email.";
		}
		if (phno.length==0 || !phoneRes) {
			err_text = err_text + "<br>Please Enter 10 digit Phone Number.";
		}
		if (comment.length==0) {
			err_text = err_text + "<br>Please Write Comment.";
		}
		if (human_ans.length==0) {
			err_text = err_text + "<br>Please Enter Human Answer";
		}
		if (err_text != "") {
			document.getElementById("err_list").innerHTML = err_text;
			return;
		}
		if (a + b != human_ans) {
			alert('Human Answer is Wrong!');
			return;
		}
		$('#loader').css('display', 'block'); 
		var xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				$('#loader').css('display', 'none');
				console.log(this.responseText);
				if (this.responseText.indexOf("Message could not be sent.") == -1 )
					alert('Form Submitted Success.');
				else
					alert('Somthing Wrong.Please Try Again!');
			 
			}
		  };
		  xhttp.open("GET", "post.php?name="+name+"&email="+email+"&phone="+phno+"&subject="+subject+"&comment="+comment, true);
		  xhttp.send();
	});
});