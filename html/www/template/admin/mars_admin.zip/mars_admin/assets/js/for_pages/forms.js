(function() {
  $(function() {
    return $('.chosen').chosen();
  });

}).call(this);
