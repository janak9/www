# Read-Excel-With-Codeigniter

Halo Coder, :D

berikut adalah sample fungsi dimana kita bisa membaca sebuah data dari file excel ,
lalu data tersebut langsung bisa di tampilkan pada halaman browser.


jadi anda tidak memerlukan config secara khusus, seperti ke database , karena fungsi ini hanya mengambil data yang terletak pada file excel , dimana file excel tersebut berada di sebuah Path / Direktori 

```public / sample.xls```

dan anda tinggal clone saja seperti berikut

```git clone https://github.com/jadirullah/Read-Excel-With-Codeigniter.git```

Berikut Priview dari hasil nya 


![alt text](https://github.com/jadirullah/Read-Excel-With-Codeigniter/blob/master/public/sample.png)

Terimakasih,


Semoga Bermanfaat :D
